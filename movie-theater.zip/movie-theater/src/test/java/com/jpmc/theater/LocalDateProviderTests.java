package com.jpmc.theater;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


public class LocalDateProviderTests {
    @Test
    void testCurrentDate() {
        System.out.println("Current Date is - " + LocalDateProvider.getInstance().currentDate());
    }

    @Test
    void testSingleTon(){
       LocalDateProvider dateProvider1= LocalDateProvider.getInstance();
       LocalDateProvider dateProvider2= LocalDateProvider.getInstance();
       Assertions.assertEquals(dateProvider1, dateProvider2);

    }
}
