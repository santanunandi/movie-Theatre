package com.jpmc.theater;

import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import org.junit.jupiter.api.Assertions;


public class MovieTests {

    @Test
    void specialMovieWith50PercentDiscount() {
        Movie spiderMan = new Movie("Spider-Man: No Way Home", Duration.ofMinutes(90),12.5, 1);
        Showing showing = new Showing(spiderMan, 5, LocalDateTime.of(LocalDate.now(), LocalTime.now()));
        Assertions.assertEquals(10, showing.calculateTicketPrice(showing));

    }
    @Test
    void specialMovieWith3DollarDiscount() {
        Movie spiderMan = new Movie("Spider-Man: No Way Home", Duration.ofMinutes(90),12.5, 1);
        Showing showing = new Showing(spiderMan, 1, LocalDateTime.of(LocalDate.now(), LocalTime.now()));
        Assertions.assertEquals(9.5, showing.calculateTicketPrice(showing));

    }
    @Test
    void specialMovieWith2DollarDiscount() {
        Movie spiderMan = new Movie("Spider-Man: No Way Home", Duration.ofMinutes(90),12.5, 1);
        Showing showing = new Showing(spiderMan, 2, LocalDateTime.of(2022,11,7,13,1));
        Assertions.assertEquals(9.375, showing.calculateTicketPrice(showing));

    }

    @Test
    void specialMovieWithNoDiscount() {
        Movie spiderMan = new Movie("Spider-Man: No Way Home", Duration.ofMinutes(90),12.5, 0);
        Showing showing = new Showing(spiderMan, 3, LocalDateTime.of(2022,11,8,10,1));
        Assertions.assertEquals(12.5, showing.calculateTicketPrice(showing));

    }
}
