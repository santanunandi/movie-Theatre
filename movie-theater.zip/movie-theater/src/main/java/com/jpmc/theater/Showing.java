package com.jpmc.theater;

import java.time.LocalDateTime;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.List;

public class Showing {
    private Movie movie;
    private int sequenceOfTheDay;
    private LocalDateTime showStartTime;

    public Showing(Movie movie, int sequenceOfTheDay, LocalDateTime showStartTime) {
        this.movie = movie;
        this.sequenceOfTheDay = sequenceOfTheDay;
        this.showStartTime = showStartTime;
    }

    public Movie getMovie() {
        return movie;
    }

    public LocalDateTime getStartTime() {
        return showStartTime;
    }

    public boolean isSequence(int sequence) {
        return this.sequenceOfTheDay == sequence;
    }

    public double getMovieFee() {
        return movie.getTicketPrice();
    }

    public int getSequenceOfTheDay() {
        return sequenceOfTheDay;
    }

    private double calculateFee(int audienceCount) {
        return calculateTicketPrice(this) * audienceCount;
    }

    public double calculateTicketPrice(Showing showing) {
        return movie.getTicketPrice() - getMaximumDiscount();
    }

    private double getMaximumDiscount() {

        double maximumDiscount = 0;

        if (Movie.MOVIE_CODE_SPECIAL == movie.getSpecialCode()) {
            if(maximumDiscount <  movie.getTicketPrice() * 0.2)  // 20% discount for special movie
                maximumDiscount  = movie.getTicketPrice() * 0.2;
        }

        if (getSequenceOfTheDay() == 1) {
            if (maximumDiscount < 3.00) // $3 discount for 1st show
                maximumDiscount =3.00;
        }
        else if (getSequenceOfTheDay() == 2) {
            if (maximumDiscount < 2.00) // $2 discount for 2nd show
                maximumDiscount =2.00;
        }

        if(getStartTime().get(ChronoField.HOUR_OF_DAY) >= 11 &&
                getStartTime().get(ChronoField.HOUR_OF_DAY) <= 16){
            if(maximumDiscount < movie.getTicketPrice() * 0.25)
                maximumDiscount = movie.getTicketPrice() * 0.25;
        }

        if(getStartTime().get(ChronoField.DAY_OF_MONTH) == 7 && maximumDiscount <1.00)
            maximumDiscount = 1.00;

        return maximumDiscount;
    }
}
