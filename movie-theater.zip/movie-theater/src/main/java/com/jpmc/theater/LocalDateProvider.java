package com.jpmc.theater;

import java.time.LocalDate;

public class LocalDateProvider {

    /**
     * @return make sure to return singleton instance
     */
    private LocalDateProvider(){

    }

    private static class LocalDataProviderHelper{
        private static final LocalDateProvider INSTANCE = new LocalDateProvider();
    }

    public static LocalDateProvider getInstance(){
        return LocalDataProviderHelper.INSTANCE;
    }

    public LocalDate currentDate() {
        return LocalDate.now();
    }
}
